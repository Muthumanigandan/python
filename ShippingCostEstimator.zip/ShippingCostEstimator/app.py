from flask import Flask, request, jsonify, render_template 
from flask_cors import CORS 
from dotenv import load_dotenv
import openai 
import os
import re

load_dotenv()

app = Flask(
    __name__,
    static_url_path='/ShippingCostEstimator/static',
    static_folder='static',
    template_folder='templates'
)
CORS(app)

openai.api_key = os.getenv("API_KEY")

if not openai.api_key:
    raise ValueError("OpenAI API key not found. Ensure it's set in the .env file.")

def estimate_shipping_cost(origin_zip, destination_zip, weight, category, shipping_date):
    prompt = f"""
    I am sending a package from {origin_zip} to {destination_zip}. 
    The package weighs {weight} kg and is of category {category}.
    The shipping date is {shipping_date}. 
    
    Please estimate the cost of shipping based on the weight, category, and date. 
    Return only the cost in USD as a number or in the format 'The estimated cost is $XX.XX'.
    """

    try:
        # Using OpenAI ChatCompletion API
        response = openai.ChatCompletion.create(
            model="gpt-3.5-turbo",
            messages=[
                {"role": "system", "content": "You are a shipping cost calculator. Always return the cost as a number or in the format 'The estimated cost is $XX.XX'."},
                {"role": "user", "content": prompt}
            ],
            temperature=0.2,
        )

        # Extract response content
        content = response['choices'][0]['message']['content'].strip()

        match = re.search(r"The estimated cost is \$?(\d+(\.\d{1,2})?)|^\$?(\d+(\.\d{1,2})?)$", content)
        if match:
            # Check which part of the regex captured the cost
            estimated_cost = float(match.group(1) or match.group(3))
            return estimated_cost
        else:
            print(f"Error: Unable to extract numeric cost from response. Response content: {content}")
            return None

    except Exception as e:
        print(f"Unexpected error: {e}")
        return None
    
@app.route('/ShippingCostEstimator/')
def home():
    return render_template('index.html')

@app.route('/ShippingCostEstimator/predict_cost', methods=['GET','POST'])
def predict_cost():
   
    data = request.get_json()
    origin_zip = data.get('origin_zip')
    destination_zip = data.get('destination_zip')

    # Combine weight_kg and weight_gm into a single weight value
    weight_kg = int(data.get('weight_kg', 0))  # Default to 0 if not provided
    weight_gm = int(data.get('weight_gm', 0))  # Default to 0 if not provided
    weight = weight_kg + (weight_gm / 1000)  # Convert grams to kilograms

    category = data.get('category')
    shipping_date = data.get('shipping_date')

    # Call the shipping cost estimation function
    estimated_cost = estimate_shipping_cost(origin_zip, destination_zip, weight, category, shipping_date)

    if estimated_cost is not None:
        return jsonify({'estimated_cost': estimated_cost})
    else:
        return jsonify({'error': 'Could not calculate cost'}), 500

if __name__ == '__main__':
    app.run(host='0.0.0.0', debug=True)
