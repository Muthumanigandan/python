import sys
import os

# Path to the directory containing your Flask app
sys.path.insert(0, os.path.dirname(__file__))

from app import app as application  # Import your Flask app instance


from dotenv import load_dotenv
load_dotenv()